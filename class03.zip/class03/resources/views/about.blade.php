<x-layout>
    <h1>this is layout</h1>
</x-layout>